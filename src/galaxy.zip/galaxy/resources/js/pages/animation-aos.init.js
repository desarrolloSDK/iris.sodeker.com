/*
Template Name: Velzon - Admin & Dashboard Template
Author: Themesbrand
Website: https://Themesbrand.com/
Contact: Themesbrand@gmail.com
File: Animatoin aos Js File
*/

AOS.init({
	easing: 'ease-out-back',
	duration: 1000
});